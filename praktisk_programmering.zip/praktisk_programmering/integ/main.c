#include <stdio.h>
#include <math.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_errno.h>
#include <stdlib.h>

double log_integrand(double x,void* params){
        return log(x)/sqrt(x);
}

double wave_norm(double x, void *params){
	double alpha = *(double *)params;
	double f = exp(-alpha*pow(x,2));
	return f;
}

double hamiltonian(double x, void *params){
	double alpha = *(double *)params;
	double f = (-pow(alpha,2)*pow(x,2)/2 + alpha/2 + pow(x,2)/2)
			*exp(-alpha*pow(x,2));
	return f;
}

int main(){
        gsl_function f;
        f.function = log_integrand;
//      f.params = NUUL;

        int limit = 100;
        double a = 0,b = 1, acc = 1e-6, eps = 1e-6, result,err;
        gsl_integration_workspace* workspace =
                gsl_integration_workspace_alloc(limit);

	gsl_integration_qags(&f,a,b,acc,eps,limit,workspace,&result,&err);
	printf("I = %g\n",result);


//	part 2
	FILE* file = fopen("ho.dat","w");

	double alpha, result_wave, result_H, error_wave, error_H;

	gsl_function Wave_norm;
	Wave_norm.function = wave_norm;
	Wave_norm.params = &alpha;

	gsl_function Hamiltonian;
	Hamiltonian.function = hamiltonian;
	Hamiltonian.params = &alpha;

	for(int x = 1; x<500; x++){
		alpha = (double) x/100;
		gsl_integration_qagi(&Wave_norm, 0,1e-8, 10, workspace, &result_wave, &error_wave);
		gsl_integration_qagi(&Hamiltonian, 0,1e-8, 100, workspace, &result_H, &error_H);
		fprintf(file, "%g %g\n", alpha, result_H/result_wave);
	}

	printf("\n1/2 is the ground state in the harmonic oscillator\n");

        gsl_integration_workspace_free(workspace);

	return 0;
}


