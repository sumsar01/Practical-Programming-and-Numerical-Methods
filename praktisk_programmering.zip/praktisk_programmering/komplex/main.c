#include "komplex.h"
#include "stdio.h"
#define TINY 1e-6

int main(){
	komplex a = {1,2}, b = {3,4};
	double x = 5;
	double y = 7;

// test komplex_add
	printf("testing komplex_add...\n");
	komplex r = komplex_add(a,b);
	komplex R = {4,6};
	komplex_print("a=",a);
	komplex_print("b=",b);
	komplex_print("a+b should   = ", R);
	komplex_print("a+b actually = ", r);

// test komplex_sub
	printf("testing komplex_add...\n");
	komplex s = komplex_sub(b,a);
	komplex S = {2,2};
	komplex_print("b-a should   = ", S);
	komplex_print("b-a actually = ", s);

// test komplex_new
	printf("testing komplex_new...\n");
	printf("x = %g\n",x);
	printf("y = %g\n",y);
	komplex h = komplex_new(x,y);
	komplex H = {5,7};
	komplex_print("x+i*y should   =",H);
	komplex_print("x+i*y actually =",h);

//test komplex_set
	komplex z;
	printf("testing komplex_set...\n");
	komplex_set(&z, a.re, a.im);
	komplex_print("z =",z);


}
